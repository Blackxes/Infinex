<?php

/*
*	html template render class
*
*	basically .. everything what you want see - this service will render it
*	use it wisely senpai	
*
*	Author: Alexander Bassov - 22.06.2016
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Service\Services;
	
	//-----------------------------------------------------------
	// used namespaces
	/* ... */
	
	//_________________________________________________________________________________________________________
	//
	class HtmltpService extends \Infinex\Core\Packs\Htmltemplateparser\HtmlTemplateParser
	{
		// variables
		/* ... */
		
		//_____________________________________________________________________________________________________
		//
		
	} //
	//
	
	//_________________________________________________________________________________________________________
	//
	
//