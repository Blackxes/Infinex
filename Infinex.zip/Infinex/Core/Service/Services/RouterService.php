<?php

/*
*	the router class
*	
*	the controller and action request will be parsed in here
*	from here you are able to get correct action
*	
*	Author: Alexander Bassov - 20.07.2016
*/
	
	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Service\Services;
	
	//-----------------------------------------------------------
	// used namespaces
	/* ... */
	
	//_________________________________________________________________________________________________________
	//
	class RouterService extends \Infinex\Core\Controlling\Router
	{
		// variables
		/* ... */
		
		//_____________________________________________________________________________________________________
		//
	
	} //
	//
	
	//_________________________________________________________________________________________________________
	//