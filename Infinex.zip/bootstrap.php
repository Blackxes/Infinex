<?php

/*
*	the sexy and essential bootstrap class
*	this is where everything starts
*	and where you can get everything you need
*	to make you application glorious!
*	
*	Author: Alexander Bassov - 21.06.2016
*/

	//_________________________________________________________________________________________________________
	// namespaces
	/* ... */
	
	//_________________________________________________________________________________________________________
	// constants
	//
	// Root directory
	define("IX_ROOT", __DIR__, 1);
	
	//_________________________________________________________________________________________________________
	// includes
	require_once(IX_ROOT . "/Infinex/Core/Bootstrap/Bootstrap.php");
	
	//_________________________________________________________________________________________________________
	//