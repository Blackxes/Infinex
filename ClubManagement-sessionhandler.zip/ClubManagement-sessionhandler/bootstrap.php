<?php

/*
*	the sexy and essential bootstrap class
*	this is where everything starts
*	and where you can get everything you need
*	to make you application glorious!
*
*	Author: Alexander Bassov - 21.06.2016
*/

	//_________________________________________________________________________________________________________
	// namespaces
	namespace Infinex;

	//_________________________________________________________________________________________________________
	// constants
	//
	// Root directory
	define("IX_ROOT", __DIR__, TRUE);

	//_________________________________________________________________________________________________________
	// includes
	require_once(IX_ROOT . "/Infinex/Core/Bootstrap/Bootstrap.php");

	//_________________________________________________________________________________________________________
