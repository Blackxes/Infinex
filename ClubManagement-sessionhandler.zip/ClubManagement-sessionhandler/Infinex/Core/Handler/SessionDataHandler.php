<?php

/*
*	management of the session data
*
*	Author: Alexander Bassov - 29.03.2017
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Handler;

	//_________________________________________________________________________________________________________
	// used namespace
	use Infinex\Core\Base\Model;
	use Infinex\Core\Debug;

	//_________________________________________________________________________________________________________
	//
	class SessionDataHandler extends Model\SessionModel
	{
		// variables
		//

		// contains the session data
		// separated by the key
		private $sessData = null;

		//-----------------------------------------------------------------------------------------------------
		//
		function __construct()
		{
			// defaults
			$this->sessData = array();
		}

		//-----------------------------------------------------------------------------------------------------
		// adds/overwrite (on permission) data
		//
		// param1	-	(Infinex\Core\Base\Model\SessionDataModel) expects the data instance
		//
		// return true - when the data has been added successfully
		// throw - when an error occured
		//		when the key is empty or not a string
		//		or when the permission to overwrite the data is false
		//
		public function addData(Infinex\Core\Base\Model\SessionDataModel $sessModel)
		{
			// validate model
			try
			{
				// validate and check wether this data is allowed to be written
				if ($this->validateDataModel($sessModel))
					throw Debug\IX_Exception('Data cant be stored', IX_CANCEL);
				// otherwise store regardless of wether this data exists or not
				// checking for overwriting permission already happened
				$this->sessData[$sessModel->getKey()] = $sessModel;
			}
			catch (Debug\IX_Exception $exception)
			{
				return $exception;
			}
		}
		
		//-----------------------------------------------------------------------------------------------------
		// returns a SessionDataModel when key is valid and found
		//
		// param1	-	(string) expects the session data key
		//
		// return SessionDataModel - when key found and valid
		// return Debug\IX_Ec
		
		// return false - when session key is invalid
		//		when session data key is empty
		//		when session data key is not string
		//		when session data key is not found
		//
		//
		public function getData(string $key)
		{
			//
			try
			{
				//
				if (!$this->validatedSessionDataKey($key))
					return false;
				// when key is valid and data exists return data
				// otherwise a new constructed Model\SessionDataModel
				return ($this->sessData[$key]) ? $this->sessData[$key] : new Model\SessionDataModel();
			}
			catch (Debug\IX_Exception $exception)
			{
				return $exception;
			}
			
			//
			return 
		}

		//-----------------------------------------------------------------------------------------------------
		// validates a session data model object
		//
		// param1	-	(Infinex\Core\Base\Model\SessionDataModel) expects the data instance
		//
		// return true - when the model is fine
		// throw - when an error occured
		//		when the key is empty or not a string
		//
		private function validateDataModel(Infinex\Core\Base\Model\SessionDataModel $model)
		{
			// check key
			if ( (!is_string($model->getKey())) || (!$model->getKey()) )
				throw new Debug\IX_Exception('Sessionkey is invalid (not a string or empty)', IX_CANCEL);

			//
			return true;
		}
		
		//-----------------------------------------------------------------------------------------------------
		// validates the key for a session data model
		//
		// param1	-	(string) expects the session data key
		//
		// return true - when key is valid
		// return false - when key is invalid
		//		key is empty
		//		key is not a string
		//
		private function validatedSessionDataKey($key)
		{
			//
			if ( (!is_string($key)) || ($key) )
				return false;
			//
			return true;
		}
		
		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//

//
