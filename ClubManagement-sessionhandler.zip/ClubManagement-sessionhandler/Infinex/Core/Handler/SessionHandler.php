<?php

/*
*	session management
*	creation saving destroying etc.
*
*	Author: Alexander Bassov - 25.03.2017
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Handler;

	//-----------------------------------------------------------
	// used namespaces
	use Infinex\Core\Base;
	use Infinex\Core\Debug;

	//_________________________________________________________________________________________________________
	//
	class SessionHandler extends Base\BaseService
	{
		// variables
		//

		// session itself
	 	private $session = null;

		// general session key
		private $sessKey = null;

		// defines wether the session is expired or not
		private $sessExpired = null;

		// session duration
		private $sessDuration = null;

		//-----------------------------------------------------------------------------------------------------
		//
		public function __construct()
		{
			//
			$this->session = array();
			//
			$this->sessKey = (defined(IX_SESSION_KEY) ? IX_SESSION_KEY : 'INFINEX');
			$this->sessExpired = (defined(IX_SESSION_KEY) ? IX_SESSION_KEY : 'INFINEX');;
			$this->sessDuration = (defined(IX_SESSION_DURATION) ? IX_SESSION_DURATION : 'INFINEX');
		}

		//-----------------------------------------------------------------------------------------------------
		// initializes the session
		//
		// return $this - when initialization was successful
		//
		public function Init()
		{
			// do initilization stuff
			$this->prepare();

			//
			return $this;
		}

		//-----------------------------------------------------------------------------------------------------
		// loads session
		//
		// return true - when session has been prepared
		//
		private function prepare()
		{
			// when either no session data exists
			// or the session expired - reset session
			if ( (!$this->load() || ($this->hasExpired()) )
				$this->reset();

			// updates current session
			$this->update();

			//
			return true;
		}

		//-----------------------------------------------------------------------------------------------------
		// checks wether the session expired or not
		//
		// return true - when the session expired
		// return false - when the session is still within the time
		//
		private function hasExpired()
		{
			// check expiration
			if ( (time() - $this->session->getLastAccess()) > $this->sessDuration )
				return true;
			//
			return false;
		}

		//-----------------------------------------------------------------------------------------------------
		// resets the session to its default
		//
		// return true  - when the reset was successful
		//
		private function reset()
		{
			// bob the session builder
			$sessBase = Base\Model\SessionModel();
			$sessBase->setId(session_id());
			$sessBase->setLastAccess(time());
			$sessBase->sessionData(array());
			//
			$this->session = $sessBase;

			//
			return true;
		}


		//-----------------------------------------------------------------------------------------------------
		// adds/overwrites (on permission) data with $key index with the given data
		//
		// param1	-	(string) expects the session data key
		// param2	-	(array) expects the session data
		// param3	-	(optional) (boolean) expects the permission to overwrite this data
		//
		// return result of 'SessionHandler::setDataByInstance()'
		//		see returns of that method for more information
		//
		public function setData($key, $data, $overwritable = false)
		{
			// create and insert via internal by instance method
			$sessData = Base\Model\SessionDataModel();
			$sessData->setKey = $key;
			$sessData->setData = $data;
			$sessData->overwritable = $overwritable;

			//
			return $this->setDataByInstance($sessData))
		}

		//-----------------------------------------------------------------------------------------------------
		// adds/overwrites (on permission) data with $key index
		// with the given data by instance of Infinex\Core\Base\Model\SessionDataModel
		//
		// param1	-	(Infinex\Core\Base\Model\SessionDataModel) expects the data model
		//		doesnt matter if it contains data or not / the key must be given
		//
		// return true - when the data has been added or already existing data with the given key
		//		has been overwritten
		// return false - when an error occured
		//		when the data key is empty or not a string
		//		when the data with the given key exists but is not allowed to be overwritten
		//
		public function setDataByInstance($sessData)
		{
			// validate
			$key = $sessData->getKey();

			// check if key is valid or the key exists and is not overwritable
			if ( ($this->validateSessionModel) && !$sessData->getOverwritable()) )
				return false;

			// set/overwrite data
			$originalSessData = $this->session->getSessionData();
			$originalSessData
		}

		//-----------------------------------------------------------------------------------------------------
		// returns the session by the given key
		//
		public function getData($key)
		{
			//
			$this->
		}

		//-----------------------------------------------------------------------------------------------------
		// checks if the
		//
		// return true - when the data exists
		// return false - when an error occured
		//		when no data has been found
		// throw - when the key is empty
		//		or the key isnt a string
		//
		public function keyExists($key)
		{
			// validate key
			if ( (!is_string($key)) || (!$key) )
				throw new Debug\IX_Exception('Session key is not a string or empty: ' . $key);

			//
			return
		}

		//-----------------------------------------------------------------------------------------------------
		// in comparisson to 'SessionHandler::hasData' this method checks if this key exists
		// and the data is not null nor false
		//
		// return true - when the

		//-----------------------------------------------------------------------------------------------------
		// stores session data into $_SESSION
		// or optionally stores $key session data
		//
		public function setSession($key = false)
		{

		}

		//-----------------------------------------------------------------------------------------------------
		// loads session
		//
		// return true - when session has been loaded
		// return false - when no session data exists
		//
		private function load()
		{
			// start/restart session
			session_start();

			// load when there is existing session data
			// otherwise create default session data
			//
			// set default / will be overwritten when its empty
			$sessData = $_SESSION[$this->sessKey];
			//
			if (!$sessData)
				return false;

			//
			return true;
		}

		//-----------------------------------------------------------------------------------------------------
		// destroys session
		//
		public function destroySession()
		{

		}

		//-----------------------------------------------------------------------------------------------------
		// unsets a specific session data
		//
		public function unsetSessionData($key)
		{

		}

		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//

//
