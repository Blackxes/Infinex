<?php

/*
*	html template render class
*
*	basically .. everything what you want see - this service will render it
*	use it wisely senpai
*
*	Author: Alexander Bassov - 22.06.2016
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Services;

	//-----------------------------------------------------------
	// used namespaces
	use Infinex\Core\Rendering;

	//_________________________________________________________________________________________________________
	//
	class HtmltpService extends Rendering\HtmlTemplateParser
	{
		// variables
		/* ... */

		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//

//
