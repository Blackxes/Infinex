<?php

/*
*	the router class
*
*	the controller and action request will be parsed in here
*	from here you are able to get correct action
*
*	Author: Alexander Bassov - 20.07.2016
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Services;

	//-----------------------------------------------------------
	// used namespaces
	use Infinex\Core\Controlling;

	//_________________________________________________________________________________________________________
	//
	class RouterService extends Controlling\Router
	{
		// variables
		/* ... */

		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//
