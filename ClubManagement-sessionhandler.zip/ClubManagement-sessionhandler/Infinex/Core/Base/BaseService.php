<?php

/*
*	handles services of this system
*	this is where all functionality
*	of the service management is in
*
*	Author: Alexander Bassov (22.06.2016)
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Base;

	//-----------------------------------------------------------
	// used namespaces
	/* ... */

	//_________________________________________________________________________________________________________
	//
	class BaseService
	{
		// variables
		//

		// identification of this service (eg. controller/rendering)
		protected		$serviceid;

		//-----------------------------------------------------------------------------------------------------
		// initialization
		//
		// param1	-	(string) expects the unique identification of the service
		//
		// return $this
		//
		public function InitService($serviceid)
		{
			$this->serviceid = $serviceid;
			return $this;
		}

		//-----------------------------------------------------------------------------------------------------
		//

		//
		//	get-functions
		//

		//-----------------------------------------------------------------------------------------------------
		// returns the service id
		//
		// return string - service id
		//
		public function getServiceId()
		{
			//
			return $this->serviceid;
		}

		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//

//
