<?php

/*
*	default model structure of the session itself
*
*	Author: Alexander Bassov - 29.03.2017
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Base\Model;

	//_________________________________________________________________________________________________________
	// used namespace
	/* ... */

	//_________________________________________________________________________________________________________
	//
	class SessionModel
	{
		// variables
		//

		// defines the session id
		private $id = null;

		// defines the last access of this page
		// contains a DateTime instance
		private $lastAccess = null;

		//-----------------------------------------------------------------------------------------------------
		//
		function __construct()
		{
			// defaults
			$this->id = 0;
			$this->lastAccess = 0;
		}

		//-----------------------------------------------------------------------------------------------------
		// defines the session id
		public function setId($id)
		{
			//
			$this->id = $id;
		}

		//-----------------------------------------------------------------------------------------------------
		// defines the last access time
		public function setLastAccess($dateTimeObject)
		{
			//
			$this->lastAccess = $dateTimeObject;
		}

		//-----------------------------------------------------------------------------------------------------
		// returns the session id
		public function getId()
		{
			//
			return $this->id;
		}

		//-----------------------------------------------------------------------------------------------------
		// returns the last access as timestamp
		public function getLastAccess()
		{
			//
			return $this->lastAccess;
		}

		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//

//
