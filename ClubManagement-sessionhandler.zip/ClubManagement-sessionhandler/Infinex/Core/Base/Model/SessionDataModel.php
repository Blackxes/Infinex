<?php

/*
*	default model structure of the session data
*
*	Author: Alexander Bassov - 29.03.2017
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Base\Model;

	//_________________________________________________________________________________________________________
	// used namespace
	/* ... */

	//_________________________________________________________________________________________________________
	//
	class SessionDataModel
	{
		// variables
		//

		// defines the session data key as string
		private $sessDataKey = null;

		// defined the permission to overwrite
		// this session data
		private $overwritable = null;

		// contains the data
		private $data = null;

		//-----------------------------------------------------------------------------------------------------
		//
		function __construct()
		{
			// defaults
			$this->$sessDataKey = '';
			$this->$overwritable = (defined('IX_SESSION_OVERWRITE_EXISTING_DATA') ? IX_SESSION_OVERWRITE_EXISTING_DATA : false);
			$this->$data = false;
		}

		//-----------------------------------------------------------------------------------------------------
		// defines the session data key
		//
		public function setSessDataKey($key)
		{
			//
			$this->sessDataKey = $key;
		}

		//-----------------------------------------------------------------------------------------------------
		// defines the permission to overwrite this session data
		//
		public function setOverwritable($permission)
		{
			//
			$this->overwritable = $permission;
		}

		//-----------------------------------------------------------------------------------------------------
		// defines the last access time
		//
		public function setData($data)
		{
			//
			$this->data = $data;
		}

		//-----------------------------------------------------------------------------------------------------
		// returns the session data key
		//
		public function getSessDataKey()
		{
			//
			return $this->sessDataKey;
		}

		//-----------------------------------------------------------------------------------------------------
		// returns the permission to overwrite this session data
		//
		public function getOverwritable()
		{
			//
			return $this->overwritable;
		}

		//-----------------------------------------------------------------------------------------------------
		// returns the last access as timestamp
		//
		public function getData()
		{
			//
			return $this->data;
		}

		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//

//
