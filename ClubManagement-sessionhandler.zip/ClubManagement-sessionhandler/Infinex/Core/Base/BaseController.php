<?php

/*
*	contains the base controller action
*	which will be always executed
*	before anything else executes
*
*	based on this actions result the further action will be handled
*
*	Author: Alexander Bassov - 08.08.2016
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Base;

	//-----------------------------------------------------------
	// used namespaces
	use Infinex\Core\Base;
	use Infinex\Core\Bootstrap;

	//_________________________________________________________________________________________________________
	//
	class BaseController extends Base\BaseAction
	{
		// variables
		/* ... */

		//-----------------------------------------------------------------------------------------------------
		//
		public function indexAction()
		{
			// base content
			if (!IX_BUILD_INFINEX_HOMESITE)
				return 'building homesite denied';

			$session = Bootstrap\Bootstrap::getService('session');


			// $session->setSession('');

			//
			return 'default basic controller';
		}

		//-----------------------------------------------------------------------------------------------------
		// preaction
		//
		public function preAction()
		{
			/* ... */
		}

		//-----------------------------------------------------------------------------------------------------
		// postaction
		//
		public function postAction()
		{
			/* ... */
		}

		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//
