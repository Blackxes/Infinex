<?php

/*
*	general configurations
*
*	Author: Alexander Bassov - 25.08.2016
*/

	//_________________________________________________________________________________________________________
	// namespace
	namespace Infinex\Core\Bootstrap;

	//_________________________________________________________________________________________________________
	// used namespace
	/* ... */

	//_________________________________________________________________________________________________________
	//
	class InfinexConf
	{
		//-----------------------------------------------------------------------------------------------------
		// debugging
		static function icConst_Debugging()
		{
			// reporting
			define('IX_DEBUG_SHOW_ERROR', TRUE, TRUE);
			//
			ini_set('display_errors', IX_DEBUG_SHOW_ERROR);
			ini_set('display_startup_errors', IX_DEBUG_SHOW_ERROR);
			error_reporting(E_ALL & ~E_NOTICE);

			// infinex status codes
			define ('IX_FALSE', 			0, TRUE);
			define ('IX_OK', 				1, TRUE);
			define ('IX_CANCEL', 			128, TRUE);
			define ('IX_INCORRECT', 		256, TRUE);
			define ('IX_WRONG_DATATYPE', 	384, TRUE);
			define ('IX_NOT_FOUND', 		404, TRUE);
			define ('IX_DEFINED', 			512, TRUE);
			define ('IX_UNDEFINED', 		513, TRUE);
		}

		//-----------------------------------------------------------------------------------------------------
		// permissions
		static function icConst_MiscPermissions()
		{
			/* ... */
		}

		//-----------------------------------------------------------------------------------------------------
		// database
		static function icConst_Database()
		{
			// login
			define('DB', 		'root', TRUE);
			define('DB_HOST', 	'localhost', TRUE);
			define('DB_USER', 	'root', TRUE);
			define('DB_PW', 	'root', TRUE);
		}

		//-----------------------------------------------------------------------------------------------------
		// tables which are needed to run this system
		static function icConst_EssentialTables()
		{
			/* ... */
		}

		//-----------------------------------------------------------------------------------------------------
		// controlling configuration
		static function icConst_Controlling()
		{
			// permission to redirect to core base controller when no controller is given
			define('IX_REDIRECT_WHENNO_CONTROLLER', 0, TRUE);

			// controller which will be used when no controller is given
			// define('IX_REDIRECT_CONTROLLER', '\Infinex\Core\Packs\Controller\InfinexController', 1);
		}

		//-----------------------------------------------------------------------------------------------------
		// service configuration
		static function icConst_ServiceConf()
		{
			// request separator
			define('IX_SERVICE_REQUEST_SEPARATOR', '.', TRUE);

			// position of the request action in the array when the request has been split (exploded)
			define('IX_SERVICE_ARRAYPOS_ACTION', 0, TRUE);

			// position of the service identification (name) when the request has been split (exploded)
			define('IX_SERVICE_ARRAYPOS_SERVICEID', 1, TRUE);
		}

		//-----------------------------------------------------------------------------------------------------
		// session configuration
		static function icConst_SessionConf()
		{
			// defines general the session key
			define('IX_SESSION_KEY', 'INFINEX', TRUE);

			// defines the default permission to overwrite existing session data
			define('IX_SESSION_OVERWRITE_EXISTING_DATA', TRUE, TRUE);

			// defined the session duration / in seconds
			define('IX_SESSION_DURATION', 10, TRUE);
		}

		//-----------------------------------------------------------------------------------------------------
		//

	} //
	//

	//_________________________________________________________________________________________________________
	//

//
